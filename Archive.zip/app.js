'use strict';

// Declare app level module which depends on views, and components
var dbuddies = angular.module('dbuddies', ['ui.router', 'dbuddies.controllers', 'vxWamp', 'oc.lazyLoad', 'ngCookies', 'ngSanitize', 'angular-carousel', 'angularMoment', 'angularModalService', '720kb.socialshare', 'ngclipboard', 'ngLoadingSpinner']);

dbuddies.config(function ($stateProvider, $urlRouterProvider, $wampProvider) {

    var WEBSOCKET_API_URL = 'wss://webapi-stage.everymatrix.com/v2';
    var DOMAIN_PREFIX = 'http://www.draftbuddies.com';

    $wampProvider.init({
        url: WEBSOCKET_API_URL,
        realm: DOMAIN_PREFIX
    });

  $stateProvider
      .state('master', {
          url: '/master',
          abstract: true,
          views: {
              sub_member: {
                  templateUrl: 'headers/member.html',
                  controller: 'sub_memberCtrl'
              },
              sub_guest: {
                  templateUrl: 'headers/guest.html',
                  controller: 'sub_guestCtrl'
              },
              content: {
                  template: '<div ui-view></div>',
                  controller: 'masterCtrl'
              }
          }
      })
      .state('master.home', {
        url: '/home',
        templateUrl: 'views/home.html',
        controller: 'homeCtrl'
      })
      .state('master.lobby', {
          url: '/lobby',
          cache: false,
          templateUrl: 'views/lobby.html',
          controller: 'lobbyCtrl'
      })
      .state('master.mycontests', {
          url: '/mycontests',
          cache: false,
          templateUrl: 'views/mycontests.html',
          controller: 'mycontestsCtrl'
      })
      .state('master.createcontest', {
          url: '/createcontest',
          templateUrl: 'views/createcontest.html',
          controller: 'createContestCtrl'
      })
      .state('master.joincontest', {
          url: '/joincontest',
          templateUrl: 'views/joincontest.html',
          controller: 'joincontestCtrl'
      })
      .state('master.livepick8', {
          url: '/livepick8',
          templateUrl: 'views/livepick8.html',
          controller: 'livepick8Ctrl'
      })
      .state('master.about', {
        url: '/about',
        templateUrl: 'views/about.html',
        controller: 'aboutCtrl'
      })
      .state('master.referfriends', {
          url: '/referfriends',
          templateUrl: 'views/referfriends.html',
          controller: 'referFriendsCtrl'
      })
      .state('master.profile', {
          url: '/profile',
          templateUrl: 'views/profile.html',
          controller: 'profileCtrl'
      })
      .state('master.depositmethods', {
          url: '/depositmethods',
          templateUrl: 'views/deposit/methods.html',
          controller: 'depositMethodsCtrl'
      })
      .state('master.paymentconfig', {
          url: '/paymentconfig',
          templateUrl: 'views/deposit/methods.html',
          controller: 'paymentConfigCtrl'
      })
      .state('master.cardpayment', {
          url: '/cardpayment',
          templateUrl: 'views/deposit/cardpayment.html',
          controller: 'cardPaymentCtrl'
      })

  $urlRouterProvider.otherwise('/master/home');

})

.run(function ($wamp, $cookies) {
    $wamp.open();
    $cookies.putObject('wampConnection', $wamp.connection);
})